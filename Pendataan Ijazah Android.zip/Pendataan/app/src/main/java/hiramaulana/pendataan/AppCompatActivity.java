package hiramaulana.pendataan;

import android.os.Bundle;

class AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
    }
}
