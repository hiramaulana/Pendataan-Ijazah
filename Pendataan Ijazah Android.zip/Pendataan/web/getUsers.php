<?php 

require_once 'config.php';

if (isset($_GET['key'])) {
	$key = $_GET['key'];
	$query = "Select * from qw_ijazah where nama_siswa LIKE '%$key$'";
	$result = mysqli_query($con, $query);
		$response = array();
		while($row = mysqli_fetch_assoc($result)){
			array_push($response,
				array(
					'nis'=>$row['nis'],
					'nama_siswa'=>$row['nama_siswa'],
					'no'=>$row['no'])
			);
		}
		echo json_encode($response);
} else{
	$query = "Select * from qw_ijazah";
	$result = mysqli_query($con, $query);
		$response = array();
		while($row = mysqli_fetch_assoc($result)){
			array_push($response,
				array(
					'nis'=>$row['nis'],
					'nama_siswa'=>$row['nama_siswa'],
					'no'=>$row['no'])
			);
		}
		echo json_encode($response);
}

mysqli_close($con);

?>