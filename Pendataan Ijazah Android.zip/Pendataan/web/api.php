<?php

require 'config.php'; 

$act = $_GET['act'];
$response = array();

	if ($act == "login") 
	{
		$username = $_POST['username'];
		$password = $_POST['password'];

		$query = mysqli_query($con, "SELECT * FROM tb_login WHERE username = '$username' and password = '$password'");
		$data  = mysqli_fetch_array($query);
		$row   = mysqli_num_rows($query);
		if ($row > 0) {
			$response['code'] = 1;
			$response['msg']   = "Successfull";
		}
		else {
			$response['code'] = 0;
			$response['msg']   = "Username or Password is wrong!";
		}
		echo json_encode($response);
	}else if ($act == "ijazah") {
		$nis = $_POST['nis'];
		$nisn = $_POST['nisn'];
		$npun = $_POST['npun'];
		$sekolah = $_POST['sekolah'];
		$no = $_POST['no'];

		$query = mysqli_query($con, "Insert Into tb_ijazah values ('$nis','$nisn','$npun','$sekolah','$no')");
		$data = mysqli_fetch_array($query);
		if ($data) {
			$response['code'] = 1;
			$response['msg']   = "Successfull";
		}else{
			$response['code'] = 0;
			$response['msg']   = "Failed!";
		}
		echo json_encode($response);
	}else if ($act == "skhun") {
		$nis = $_POST['nis'];
		$nisn = $_POST['nisn'];
		$npun = $_POST['npun'];
		$sekolah = $_POST['sekolah'];
		$npsn = $_POST['npsn'];
		$no = $_POST['no'];

		$query = mysqli_query($con, "Insert Into tb_skhun values ('$nis','$nisn','$npun','$sekolah','$npsn','$no')");
		$data = mysqli_fetch_array($query);
		if ($data) {
			$response['code'] = 1;
			$response['msg']   = "Successfull";
		}else{
			$response['code'] = 0;
			$response['msg']   = "Failed!";
		}
		echo json_encode($response);
	}

?>