
<?php 

include '../config.php';

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Lihat Data</title>
	<link rel="stylesheet" type="text/css" href="../web/asset/DataTables/datatables.css">
	<link rel="stylesheet" href="../web/asset/css/mains.css">
	<link rel="stylesheet" href="../web/asset/css/fa/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Instruction Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript">
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	<style>
		body{
			
		}
	</style>
	<title>Laporan</title>
</head>
<body>
<div class="container">
	<form method="post">
		<div class="row">
			<div class="" style="margin: auto;">
				<h1 style="text-align: center; color: blue;margin-top: 50px;">Pencarian Ijazah</h1>
				<hr>
				<table class="table-bordered" id="example">
					
					<thead>
						<tr>
							<th>No</th>
							<th>Nis</th>
							<th>Nama Siswa</th>
							<th>No Ijazah</th>
						</tr>
					</thead>
					<tbody>
					<?php
						@$no;
						$sql = "select * from qw_ijazah";
						$query = mysqli_query($con, $sql);
						while($data = mysqli_fetch_array($query)){ @$no++
					?>
						<tr>
							<td><?= $no ?></td>
							<td><?= $data['nis'] ?></td>
							<td><?= $data['nama_siswa'] ?></td>
							<td><?= $data['no'] ?></td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</form>
</div>
</body>

<?php include '../web/asset/js.php'; ?>
<script type="text/javascript" src="../web/asset/js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="../web/asset/js/bootstrap.js"></script>
<script type="text/javascript" src="../web/asset/DataTables/datatables.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

</html>
