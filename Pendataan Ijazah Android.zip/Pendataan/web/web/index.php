<?php 
error_reporting(0);
session_start();
include '../config.php';

if (isset($_POST['getLogin'])) {
    $sql = "SELECT * FROM tb_siswa WHERE nis = '$_POST[username]' and nis = '$_POST[password]'";
        $query = mysqli_query($con, $sql);
        $tampil = mysqli_fetch_array($query);
        $cek = mysqli_num_rows($query);
        if ($cek > 0) {
            echo "<script>alert('Login Berhasil');document.location.href='siswa/input.php?menu=data&nis=$_POST[username]'</script>";
        } else {
            echo "<script>alert('Login gagal cek username dan password !!');</script>";
        }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pendataan Ijazah & Skhun</title>
    <link rel="stylesheet" href="asset/css/mains.css">
    <link rel="stylesheet" href="asset/css/fa/css/font-awesome.min.css">

    <style>
        body{
            background: #55E6C1;
        }
    </style>
</head>
<body>
    <section class="container">
        <form method="post" class="col-md-5 offset-md-3">
            
            <div class="jumbotron my-5" style="margin-left: 25px">
                <h3 style="text-align: center">Silahkan Login Terlebih Dahulu</h3>
                <br>
          <div class="form-group">
            <label class="control-label">USERNAME</label>
            <input class="form-control" type="text" autofocus name="username" autocomplete="off" autofocus="on" required>
          </div>
          <div class="form-group">
            <label class="control-label">PASSWORD</label>
            <input class="form-control" type="password" name="password" required>
          </div>
          
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block" name="getLogin"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
          </div>
      </div>
     </form> 
    </section>
</body>
<?php include 'asset/js.php'; ?>
</html>
<script type="text/javascript">
    $(document).ready(function() {
                $('#dmerek').DataTable();
            } );
</script>
<script>
    setTimeout(function() {
    $("#alerts").slideToggle();
  }, 12000);
</script>