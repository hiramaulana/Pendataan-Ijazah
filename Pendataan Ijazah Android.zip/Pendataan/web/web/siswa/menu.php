<?php 

session_start();
include '../../config.php';

@$nis = $_GET[nis];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pendataan Ijazah & Skhun</title>
    <link rel="stylesheet" href="../asset/css/mains.css">
    <link rel="stylesheet" href="../asset/css/fa/css/font-awesome.min.css">

    <style>
        body{
            background: #55E6C1;
        }
    </style>
</head>
<body>
    <section class="container">
        <form method="post" class="col-md-5 offset-md-3">
            <div class="jumbotron my-5" style="margin-left: 25px">
                <h3 style="text-align: center">Menu</h3>
                <br>
            <div class="form-group">
              <a href="laporan.php?menu=data&nis=<?php echo $nis ?>" style="color: white" class="btn btn-primary btn-block">Lihat Data</a>
           </div>
           <div class="form-group">
              <a href="logout.php" style="color: white" class="btn btn-primary btn-block">Logout</a>
           </div>
      </div>
     </form> 
    </section>
</body>
<?php include '../asset/js.php'; ?>
</html>
<script type="text/javascript">
    $(document).ready(function() {
                $('#dmerek').DataTable();
            } );
</script>
<script>
    setTimeout(function() {
    $("#alerts").slideToggle();
  }, 12000);
</script>