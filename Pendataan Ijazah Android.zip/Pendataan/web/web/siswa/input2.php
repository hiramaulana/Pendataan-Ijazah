<?php 

session_start();

error_reporting(0);
include '../../config.php';

@$nis = $_GET[nis];

if (isset($_POST['submit1'])) {
    $upload1 = $nama_file = $_FILES['foto']['name'];
    $tmp_file = $_FILES['foto']['tmp_name'];
    move_uploaded_file($tmp_file,"foto/$nama_file");
    $cek = "select nis from tb_ijazah where nis = '$_POST[nis]'";
    $cek1 = mysqli_query($con, $cek);
    $cek = mysqli_num_rows($cek1);
    if ($cek > 0) {
        echo "<script>alert('Nis Sudah Terdaftar')</script>";
    } else {
        @$no = $_POST['no1'] . " " . $_POST['no2'] . " " . $_POST['no3'];
        $sql = "insert into tb_ijazah values ('$_POST[nis]','$_POST[nisn]','$_POST[npun]','$_POST[sekolah]','$no')";
        $query = mysqli_query($con, $sql);
        if ($query) {
            echo "<script>alert('Success...');document.location.href='input.php?menu=data&input=skhun'</script>";
        }
    }
}

if (isset($_POST['submit2'])) {
    $upload1 = $nama_file = $_FILES['foto']['name'];
    $tmp_file = $_FILES['foto']['tmp_name'];
    move_uploaded_file($tmp_file,"../foto/$nama_file");
    $cek = "select nis from tb_skhun where nis = '$_POST[nis]'";
    $cek1 = mysqli_query($con, $cek);
    $cek = mysqli_num_rows($cek1);
    if ($cek > 0) {
        echo "<script>alert('Nis Sudah Terdaftar')</script>";
    } else {
        @$no = $_POST['no1'] . " " . $_POST['no2'] . " " . $_POST['no3'];
    $sql = "insert into tb_skhun values ('$_GET[nis]','$_POST[nisn]','$_POST[npun]','$_POST[sekolah]','$_POST[npsn]','$no')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        echo "<script>alert('Success...');document.location.href='menu.php?menu=data&nis=$_GET[nis]'</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pendataan Ijazah & Skhun</title>
    <link rel="stylesheet" href="../asset/css/mains.css">
    <link rel="stylesheet" href="../asset/css/fa/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Instruction Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript">
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <style>
        body{
            background: #55E6C1;
        }
    </style>
</head>
<body>
    <section class="container">
        <form method="post" class="col-md-7 offset-md-2" enctype="multipart/form-data">
            <?php 

            @$cek = "select nis from tb_skhun where nis = '$_GET[nis]'";
            $cek1 = mysqli_query($con, $cek);
            $cek = mysqli_num_rows($cek1);
            if ($cek > 0) {
                echo "<script>alert('Anda Sudah Terdaftar');document.location.href='menu.php?menu=data&nis=$_GET[nis]'</script>";
            }else{ ?>
            <div class="jumbotron my-5" style="margin-left: 25px">
                <h3 style="text-align: center">Pendataan SKHUN</h3>
                <br>
                <div class="form-group">
                    <label for="">Nomor Induk Siswa</label>
                    <input type="number" value="<?php echo $nis ?>" name="nis" class="form-control" placeholder="" disabled>
                </div>
                <div class="form-group">
                    <label for="" style="margin-top: 16px">Nomor Induk Siswa Nasional</label>
                    <input type="number" value="" name="nisn" class="form-control" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Nomor Peserta Ujian Nasional</label>
                    <input type="text" value="" name="npun" class="form-control" placeholder="0-00-00-00-000-000-0">
                </div>
                <div class="form-group">
                    <label for="">Sekolah Asal</label>
                    <input type="text" value="" name="sekolah" class="form-control" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Nomor Pokok Sekolah Nasional</label>
                    <input type="text" value="" name="npsn" class="form-control" placeholder="">
                </div>
                <div class="form-group">
                    <label for="">Nomor SKHUN</label><br>
                    <input type="text" value="" name="no1" class="form-control" placeholder="XX-00" style="width: 130px; float: left;">
                    <input type="text" value="" name="no2" class="form-control" placeholder="X" style="width: 130px; float: left;">
                    <input type="text" value="" name="no3" class="form-control" placeholder="0000000" style="width: 259px; float: left;" >
                </div>
                <!-- <div class="form-group">
                    <label for="" style="margin-top: 16px">Foto SKHUN</label><br>
                    <input type="file" name="foto" value="<?php echo @$edit['foto'] ?>"  class="form-control" ><?php echo @$gambar ?>
                </div> -->
                <div class="form-group">
                    <label style="margin-top: 16px"></label>
                    <button class="btn btn-primary btn-block" name="submit2">Submit</button>
                 </div>
                 <div class="form-group">
                    <a href="menu.php" style="color: white" class="btn btn-success btn-block">Kembali</a>
                 </div>
            </div>
            <?php } ?>
        </form> 
    </section>
</body>
<?php include '../asset/js.php'; ?>
</html>
<script type="text/javascript">
    $(document).ready(function() {
                $('#dmerek').DataTable();
            } );
</script>
<script>
    setTimeout(function() {
    $("#alerts").slideToggle();
  }, 12000);
</script>