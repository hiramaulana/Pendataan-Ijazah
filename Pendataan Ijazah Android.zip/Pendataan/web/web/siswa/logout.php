<?php 

include '../../config.php';



?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
</head>
<body>

<?php 
@session_start();
session_destroy();
echo "<script>alert('Selamat Tinggal');window.location.href='../index.php'</script>";
?>

</body>
</html>