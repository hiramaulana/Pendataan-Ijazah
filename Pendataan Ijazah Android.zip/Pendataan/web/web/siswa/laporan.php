<?php  

session_start();
error_reporting(0);
include '../../config.php';

@$nis = $_GET[nis];

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Lihat Data</title>
	<link rel="stylesheet" type="text/css" href="../asset/DataTables/datatables.css">
	<link rel="stylesheet" href="../asset/css/mains.css">
	<link rel="stylesheet" href="../asset/css/fa/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Instruction Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript">
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	<style>
		body{
			background: #55E6C1;
		}
	</style>
</head>
<body>
	<form method="post">
		<table align="center">
			<br>
				<tr>
					<td><h1><a href="laporan.php?menu=data&lap=ijazah&nis=<?php echo $nis ?>">Ijazah |</a></h1></td>
					<td><h1><a href="laporan.php?menu=data&lap=skhun&nis=<?php echo $nis ?>">SKHUN | </a></h1></td>
					<td><h1><a href="menu.php?menu=data&lap=skhun&nis=<?php echo $nis ?>">Kembali </a></h1></td>
				</tr>
			</table>
			<div class="col-md-8" style="margin: auto">
				<?php if(@$_GET['lap']=="ijazah") { ?>
				<hr>
				<div class="tile">
					<h1>Ijazah</h1>
					<hr>
					<table class="table table-bordered" id="example">
						<thead>
							<tr>
								<th>No</th>
								<th>Nis</th>
								<th>Nama Siswa</th>
								<th>Rayon</th>
								<th>NISN</th>
								<th>NPUN</th>
								<th>No Ijazah</th>
								<!-- <th>Aksi</th> -->
							</tr>
						</thead>
						<tbody>
						<?php  
						$no = 0;
						$sql = "select * from qw_ijazah where nis = $_GET[nis]";
						$query = mysqli_query($con,$sql);
						while ($data = mysqli_fetch_array($query)) { $no++
						?>
							<tr>
								<td><?= $no ?></td>
								<td><?= $data['nis'] ?></td>
								<td><?= $data['nama_siswa'] ?></td>
								<td><?= $data['rayon'] ?></td>
								<td><?= $data['nisn'] ?></td>
								<td><?= $data['npun'] ?></td>
								<td><?= $data['no'] ?></td>
								<!-- <td><img style="width: 50px; height: 50px" src="../foto/<?php echo $data['foto']; ?>"></td> -->
								<!-- <td><a href="unduh.php?nis=<?php echo $data['nis'] ?>" class="btn btn-success btn-block">Unduh Foto</a></td> -->
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
				<?php } ?>
				<?php if(@$_GET['lap']=="skhun") { ?>
				<hr>
				<div class="tile">
					<h1>SKHUN</h1>
					<hr>
					<table class="table table-bordered" id="example">
						<thead>
							<tr>
								<th>No</th>
								<th>Nis</th>
								<th>Nama Siswa</th>
								<th>Rayon</th>
								<th>NISN</th>
								<th>NPUN</th>
								<th>No SKHUN</th>
								<th>NPSN</th>
								<!-- <th>Foto</th> -->
								<!-- <th>Aksi</th> -->
							</tr>
						</thead>
						<tbody>
						<?php  
						$no = 0;
						$sql = "select * from qw_skhun where nis = $_GET[nis]";
						$query = mysqli_query($con,$sql);
						while ($data = mysqli_fetch_array($query)) { $no++
						?>
							<tr>
								<td><?= $no ?></td>
								<td><?= $data['nis'] ?></td>
								<td><?= $data['nama_siswa'] ?></td>
								<td><?= $data['rayon'] ?></td>
								<td><?= $data['nisn'] ?></td>
								<td><?= $data['npun'] ?></td>
								<td><?= $data['no'] ?></td>
								<td><?= $data['npsn'] ?></td>
								<!-- <td><img style="width: 50px; height: 50px" src="../foto/<?php echo $data['foto']; ?>"></td> -->
								<!-- <td><a href="unduh.php?nis=<?php echo $data['nis'] ?>" class="btn btn-success btn-block">Unduh Foto</a></td> -->
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
				<?php } ?>
			</div>
		</div>
	</form>

<?php include '../asset/js.php'; ?>
<script type="text/javascript" src="../asset/js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="../asset/js/bootstrap.js"></script>
<script type="text/javascript" src="../asset/DataTables/datatables.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
</body>
</html>

