-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2019 at 08:53 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pendataan`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `qw_ijazah`
-- (See below for the actual view)
--
CREATE TABLE `qw_ijazah` (
`nis` int(8)
,`nama_siswa` varchar(34)
,`rayon` varchar(5)
,`nisn` int(11)
,`npun` varchar(25)
,`no` varchar(25)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `qw_skhun`
-- (See below for the actual view)
--
CREATE TABLE `qw_skhun` (
`nis` int(8)
,`nama_siswa` varchar(34)
,`rayon` varchar(5)
,`nisn` int(11)
,`npun` varchar(25)
,`no` varchar(25)
,`npsn` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `tb_ijazah`
--

CREATE TABLE `tb_ijazah` (
  `nis` int(11) NOT NULL,
  `nisn` int(11) NOT NULL,
  `npun` varchar(25) NOT NULL,
  `sekolah` varchar(225) NOT NULL,
  `no` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_ijazah`
--

INSERT INTO `tb_ijazah` (`nis`, `nisn`, `npun`, `sekolah`, `no`) VALUES
(11605303, 11605303, '11605303', 'Test', 'DN-01 DI/03 6492101'),
(11605304, 11605304, '11605304', 'Test', 'DN-01 DI/03 6492102'),
(11605305, 11605305, '11605305', 'Test', 'DN-01 DI/03 6492103'),
(11605306, 11605306, '11605306', 'Test', 'DN-01 DI/03 6492104'),
(11605307, 11605307, '11605307', 'Test', 'DN-01 DI/03 6492105'),
(11605308, 11605308, '11605308', 'Test', 'DN-01 DI/03 6492106'),
(11605309, 11605309, '11605309', 'Test', 'DN-01 DI/03 6492107'),
(11605310, 11605310, '11605310', 'Test', 'DN-01 DI/03 6492108'),
(11605311, 11605311, '11605311', 'Test', 'DN-01 DI/03 6492109'),
(11605312, 11605312, '11605312', 'Test', 'DN-01 DI/03 6492110'),
(11605511, 11605511, '11605511', 'Test', 'DN-01 DI/02 0698223'),
(11605512, 11605512, '11605512', 'Test', 'DN-01 DI/03 6492856'),
(11605603, 11605603, '11605603', 'Test', 'DN-04 DI/04 7552966');

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE `tb_login` (
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_login`
--

INSERT INTO `tb_login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `nis` int(8) NOT NULL,
  `nama_siswa` varchar(34) DEFAULT NULL,
  `jk` varchar(1) DEFAULT NULL,
  `rayon` varchar(5) DEFAULT NULL,
  `rombel` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`nis`, `nama_siswa`, `jk`, `rayon`, `rombel`) VALUES
(11504919, 'Hilman Mubaroq', 'L', 'Wik 3', 'MMD XI-3'),
(11504987, 'Mekky Gideon Kikhau', 'L', 'Cis 4', 'TKJ XI-2'),
(11505010, 'Muhamad Deri Pratama Suhendi', 'L', 'Cia 1', 'RPL XI-1'),
(11505148, 'Raymond Aura Liel Sugianto', 'L', 'Cis 6', 'TKJ XI-1'),
(11605303, 'Abdulwafi Nurinsani', 'L', 'Cia 1', 'PMN XI-1'),
(11605304, 'Abdurohman', 'L', 'Cia 3', 'TKJ XI-2'),
(11605305, 'Abdussalam Husein', 'L', 'Cic 4', 'PMN XI-2'),
(11605306, 'Abil Muhamad Imani', 'L', 'Cis 4', 'RPL XI-3'),
(11605307, 'Achmad Rifaldy', 'L', 'Cic 3', 'PMN XI-1'),
(11605308, 'Adam Bahtiar Firdaus', 'L', 'Cic 6', 'RPL XI-3'),
(11605309, 'Adam Rahmat', 'L', 'Wik 1', 'TKJ XI-2'),
(11605310, 'Ade Ardiansyah Maulana', 'L', 'Cib 3', 'PMN XI-2'),
(11605312, 'Adi Wijaya', 'L', 'Taj 2', 'MMD XI-2'),
(11605313, 'Aditya Dwi Septiyanto', 'L', 'Cic 4', 'PMN XI-1'),
(11605314, 'Aditya Rama Putra', 'L', 'Taj 3', 'PMN XI-2'),
(11605315, 'Aditya Ridwan Nugraha', 'L', 'Cic 3', 'RPL XI-1'),
(11605316, 'Aditya Sukma Nur Alam', 'L', 'Wik 2', 'RPL XI-1'),
(11605317, 'Aditya Vio Gigantara', 'L', 'Cis 2', 'TKJ XI-1'),
(11605319, 'Adriansyah Ramadhan', 'L', 'Cic 7', 'RPL XI-3'),
(11605320, 'Aghniya Zahra Ainiy', 'P', 'Cia 2', 'MMD XI-3'),
(11605321, 'Agnesya Azzahra Anis', 'P', 'Cis 2', 'RPL XI-3'),
(11605322, 'Agung Fadilah', 'P', 'Cia 5', 'PMN XI-2'),
(11605323, 'Agung Mahariyad', 'L', 'Cia 5', 'RPL XI-4'),
(11605324, 'Agung Pratama', 'L', 'Cic 3', 'RPL XI-1'),
(11605325, 'Agung Ramadan', 'L', 'Cia 3', 'TKJ XI-2'),
(11605326, 'Ahmad Rahbar Rausanfikri Alwavy', 'L', 'Cis 2', 'RPL XI-3'),
(11605327, 'Ahmad Rifky Fauzi', 'L', 'Cic 5', 'RPL XI-3'),
(11605328, 'Ahmad Yoga Lutvi', 'L', 'Cia 5', 'MMD XI-3'),
(11605329, 'Ahmad Yunus Sulaeman', 'L', 'Cis 5', 'TKJ XI-1'),
(11605330, 'Ahmad Zulfikar', 'L', 'Cis 4', 'RPL XI-3'),
(11605331, 'Aimatul Khoeriyah', 'P', 'Cib 3', 'APK XI-1'),
(11605332, 'Aisha Febrianti', 'P', 'Cia 1', 'APK XI-4'),
(11605333, 'Ajeng Mutiara Ningtyas', 'P', 'Taj 4', 'PMN XI-2'),
(11605334, 'Aji Maulana Malik', 'L', 'Cia 1', 'PMN XI-2'),
(11605335, 'Al - Crasta Reixena Syam', 'P', 'Cis 5', 'RPL XI-2'),
(11605336, 'Aldi Sugandi', 'L', 'Cia 5', 'PMN XI-1'),
(11605338, 'Aldiza Putri Mulphyani', 'P', 'Cib 3', 'APK XI-2'),
(11605339, 'Aldo Alamsyah', 'L', 'Taj 5', 'PMN XI-1'),
(11605340, 'Alexandra Kiranti Lauwe', 'P', 'Cis 6', 'MMD XI-1'),
(11605341, 'Alfani', 'P', 'Cib 2', 'MMD XI-3'),
(11605342, 'Alfian Muzaki', 'L', 'Cic 6', 'TKJ XI-1'),
(11605343, 'Alfid Nurhakim', 'L', 'Cic 6', 'PMN XI-2'),
(11605344, 'Alfiyah Abdullah', 'P', 'Wik 4', 'APK XI-1'),
(11605346, 'Alif Arya Satria', 'L', 'Cia 5', 'TKJ XI-2'),
(11605347, 'Alif Rizky Nursyahputra', 'L', 'Cis 2', 'MMD XI-1'),
(11605348, 'Alifah Ayudia Rachman', 'P', 'Cic 6', 'MMD XI-3'),
(11605349, 'Alma Suci Rahmadani', 'P', 'Cic 7', 'APK XI-3'),
(11605350, 'Almeyda Dwinugroho Dewanto', 'L', 'Cic 6', 'TKJ XI-2'),
(11605351, 'Alvian Adi Wibowo', 'L', 'Wik 4', 'PMN XI-2'),
(11605352, 'Alvin Reyvaldo', 'L', 'Suk 1', 'RPL XI-4'),
(11605353, 'Alvira Erliana Putri', 'P', 'Cia 1', 'TKJ XI-2'),
(11605354, 'Alwan Nauval', 'L', 'Cib 3', 'MMD XI-2'),
(11605355, 'Alya Nasywa Martafianni', 'P', 'Cib 2', 'APK XI-4'),
(11605356, 'Amalia Nur Fitri Yani', 'P', 'Cis 5', 'APK XI-2'),
(11605357, 'Amalia Tiara Galuh', 'P', 'Cic 5', 'MMD XI-1'),
(11605358, 'Amrina', 'P', 'Cis 5', 'RPL XI-2'),
(11605359, 'Ananda Restyane', 'P', 'Cia 4', 'APK XI-1'),
(11605360, 'Ananda Rezaldy', 'L', 'Cia 5', 'RPL XI-2'),
(11605361, 'Andhika Navira Dillah Putra', 'L', 'Cis 4', 'MMD XI-3'),
(11605362, 'Andika Darmansyah', 'L', 'Taj 3', 'TKJ XI-2'),
(11605363, 'Andika Rizky Nugraha', 'L', 'Wik 4', 'APK XI-1'),
(11605364, 'Anelia Tri Oktaviani', 'P', 'Taj 4', 'APK XI-4'),
(11605365, 'Angelia Nurjanah', 'P', 'Taj 5', 'APK XI-1'),
(11605366, 'Angga Aditiya Nugraha', 'L', 'Cic 6', 'TKJ XI-1'),
(11605367, 'Angga Ardiansyah', 'L', 'Cib 3', 'TKJ XI-1'),
(11605368, 'Angga Khoerudin', 'L', 'Cic 3', 'MMD XI-2'),
(11605369, 'Angga Yudistira Ramadan', 'L', 'Taj 2', 'RPL XI-1'),
(11605370, 'Anggi Febryanti', 'P', 'Wik 3', 'MMD XI-2'),
(11605371, 'Ani Apriliani', 'P', 'Cib 2', 'APK XI-1'),
(11605372, 'Anis Fitria Nandani', 'P', 'Taj 2', 'RPL XI-4'),
(11605373, 'Anis Humanisa', 'P', 'Cic 3', 'RPL XI-1'),
(11605374, 'Anisa', 'P', 'Taj 4', 'PMN XI-1'),
(11605375, 'Anisa Novianti Sulbi', 'P', 'Cis 2', 'APK XI-1'),
(11605376, 'Anisa Rahman', 'P', 'Taj 3', 'APK XI-2'),
(11605377, 'Annisa Triani', 'P', 'Suk 1', 'RPL XI-3'),
(11605378, 'Anita Natasya', 'P', 'Taj 5', 'APK XI-3'),
(11605379, 'Annisa Fitria Nur Yavana', 'P', 'Wik 4', 'RPL XI-2'),
(11605380, 'Annisa Halimatussadiah', 'P', 'Cis 4', 'APK XI-2'),
(11605381, 'Apriliani Sugiarti', 'P', 'Cib 1', 'APK XI-3'),
(11605382, 'Aqiella Triana Furri Suryono', 'P', 'Cis 1', 'APK XI-4'),
(11605383, 'Aqsyal Nauval Gusman', 'L', 'Taj 5', 'RPL XI-1'),
(11605384, 'Ardy Wira Priyatna', 'L', 'Cic 3', 'TKJ XI-1'),
(11605385, 'Ari Amin Hawari', 'L', 'Wik 4', 'PMN XI-1'),
(11605386, 'Arief Rahman Hakim', 'L', 'Cis 3', 'RPL XI-4'),
(11605387, 'Arif Febriyanto', 'L', 'Wik 1', 'MMD XI-2'),
(11605388, 'Arief Raja Bestari', 'L', 'Wik 4', 'TKJ XI-2'),
(11605389, 'Ariyana Abdurahman', 'L', 'Cis 3', 'TKJ XI-1'),
(11605390, 'Arsyil Yazmar', 'L', 'Taj 5', 'MMD XI-1'),
(11605391, 'Asep Suryadin', 'L', 'Cic 1', 'PMN XI-2'),
(11605392, 'Astiawati Widyasari', 'P', 'Cia 1', 'APK XI-3'),
(11605393, 'Athara Hegar Sukma Perdana', 'L', 'Wik 4', 'MMD XI-1'),
(11605394, 'Audia Asyifatul Khumaeroh', 'P', 'Cis 5', 'APK XI-2'),
(11605395, 'Aulia Azzahra Ramadhani', 'P', 'Cic 7', 'APK XI-4'),
(11605396, 'Aulia Syatifa', 'P', 'Cis 5', 'APK XI-4'),
(11605397, 'Aurelya Amatul Zahwa', 'P', 'Cis 6', 'APK XI-3'),
(11605398, 'Ayu Rahma Indra Saputri', 'P', 'Cia 1', 'RPL XI-4'),
(11605399, 'Ayu Yulia', 'P', 'Taj 1', 'TKJ XI-1'),
(11605400, 'Azhar At Zauhar Dripana', 'L', 'Cia 2', 'RPL XI-3'),
(11605401, 'Azzahra Annisa Listanto', 'P', 'Cia 4', 'MMD XI-2'),
(11605402, 'Bagus Aji Ikranegara', 'L', 'Cib 1', 'PMN XI-1'),
(11605403, 'Bambang Aryo Yudha Jaya Wijaya K', 'L', 'Cib 2', 'TKJ XI-1'),
(11605404, 'Bambang Setiawan', 'L', 'Cib 3', 'PMN XI-1'),
(11605405, 'Bayu Febrian Isnin', 'L', 'Cis 4', 'MMD XI-3'),
(11605406, 'Bunga Resta Wijaya', 'P', 'Cic 7', 'RPL XI-3'),
(11605407, 'Candra Nispuana', 'L', 'Taj 3', 'TKJ XI-2'),
(11605408, 'Chika Cantika Dachlan', 'P', 'Cis 2', 'MMD XI-3'),
(11605409, 'Cindy Arsita Syaharani', 'P', 'Cic 1', 'PMN XI-1'),
(11605410, 'Citra Livia Hutasoit', 'P', 'Suk 1', 'APK XI-4'),
(11605411, 'Cucu Patonah', 'P', 'Cis 4', 'APK XI-4'),
(11605412, 'Cut Sandra Faradilla Febrianti', 'P', 'Cis 5', 'MMD XI-3'),
(11605413, 'Dafa Lutfian', 'L', 'Taj 4', 'RPL XI-4'),
(11605414, 'Dahlia Pertiwi Kalsum', 'P', 'Cic 1', 'APK XI-1'),
(11605415, 'Daniel A Syariff', 'L', 'Cib 2', 'RPL XI-4'),
(11605417, 'Danu Setyo Nugroho', 'L', 'Cib 1', 'TKJ XI-2'),
(11605418, 'Daura Laurensa Ratna Sari', 'P', 'Cis 5', 'RPL XI-3'),
(11605419, 'Davi Jordani Setiawan', 'L', 'Cis 3', 'RPL XI-4'),
(11605420, 'Dea Dwi Purwanti', 'P', 'Cia 3', 'APK XI-1'),
(11605421, 'Deansa', 'P', 'Taj 4', 'APK XI-4'),
(11605422, 'Debby Aliya Putri', 'P', 'Cia 1', 'TKJ XI-2'),
(11605423, 'Dellaneira Siska Widyawati', 'P', 'Cic 6', 'APK XI-1'),
(11605424, 'Deni Firmansyah', 'L', 'Cib 3', 'PMN XI-1'),
(11605425, 'Deni Pratama', 'L', 'Cib 1', 'MMD XI-1'),
(11605426, 'Denny Dolok Partala', 'L', 'Suk 1', 'RPL XI-2'),
(11605427, 'Deri Sukandar', 'L', 'Cib 2', 'TKJ XI-2'),
(11605428, 'Destia Audianti', 'P', 'Taj 5', 'MMD XI-1'),
(11605429, 'Destianis Ocktavia S', 'P', 'Suk 1', 'RPL XI-4'),
(11605430, 'Dewi Astuti', 'P', 'Cic 3', 'APK XI-3'),
(11605431, 'Dewi Herawati', 'P', 'Taj 3', 'MMD XI-1'),
(11605432, 'Dewi Puspitasari', 'P', 'Cia 2', 'MMD XI-3'),
(11605433, 'Dewi Sarifah Ambami', 'P', 'Cis 6', 'RPL XI-2'),
(11605434, 'Dewo Ananda Prasetyo', 'L', 'Cic 6', 'MMD XI-1'),
(11605436, 'Dhika Pramudia', 'L', 'Wik 4', 'APK XI-2'),
(11605437, 'Dian Indria Wati', 'P', 'Cis 6', 'APK XI-3'),
(11605438, 'Dika Alfarell Haidir Ramdani', 'L', 'Taj 4', 'RPL XI-2'),
(11605439, 'Dila Aprilia Ramdini', 'P', 'Taj 1', 'APK XI-3'),
(11605440, 'Dimas Darmawangsa Putra Perdana', 'L', 'Cia 3', 'PMN XI-1'),
(11605441, 'Dimas Hadiwibowo', 'L', 'Wik 2', 'RPL XI-3'),
(11605442, 'Dimas Sidiq Permana', 'L', 'Cis 5', 'RPL XI-3'),
(11605443, 'Dina Yulianti', 'P', 'Cis 2', 'APK XI-2'),
(11605444, 'Dinar Arisandi', 'L', 'Suk 1', 'RPL XI-3'),
(11605445, 'Dinda Amartya Riansyah', 'P', 'Cis 2', 'MMD XI-3'),
(11605446, 'Dita Dwi Cahyani', 'P', 'Cic 6', 'RPL XI-1'),
(11605447, 'Dita Lestari', 'P', 'Wik 3', 'MMD XI-3'),
(11605448, 'Dita Oktavia', 'P', 'Taj 5', 'PMN XI-1'),
(11605449, 'Dwi Ayu Widiyanti', 'P', 'Cic 1', 'APK XI-2'),
(11605450, 'Dwi Tantri', 'P', 'Cis 4', 'APK XI-3'),
(11605451, 'Dyah Ayu Gitaswari Paramitha', 'P', 'Cia 3', 'APK XI-3'),
(11605452, 'Dzikry Darmawan Pratama', 'L', 'Taj 5', 'TKJ XI-2'),
(11605453, 'Elih', 'P', 'Cia 5', 'APK XI-4'),
(11605454, 'Elizabeth Sharon Jily Onggara', 'P', 'Cis 5', 'MMD XI-2'),
(11605455, 'Elsa Aprilia Azzahra', 'P', 'Cib 3', 'RPL XI-3'),
(11605456, 'Elsa Febriana', 'P', 'Cia 5', 'APK XI-3'),
(11605457, 'Elsa Sri Wahyuni', 'P', 'Taj 3', 'APK XI-4'),
(11605459, 'Eneng Nova Permatasari', 'P', 'Cia 4', 'APK XI-1'),
(11605460, 'Eneng Winda Sari', 'P', 'Cia 4', 'MMD XI-2'),
(11605461, 'Eriansyah Erangga', 'L', 'Cia 2', 'TKJ XI-1'),
(11605462, 'Erisa Sri Aulia Dewi', 'P', 'Wik 4', 'APK XI-1'),
(11605464, 'Erza Putri Suryamulyawan', 'P', 'Cic 1', 'APK XI-2'),
(11605465, 'Eva Fauziah Indriani', 'P', 'Cib 2', 'MMD XI-2'),
(11605466, 'Evita Febriyanty', 'P', 'Cis 1', 'RPL XI-1'),
(11605467, 'Fachrunisa Ardiani', 'P', 'Cic 6', 'RPL XI-1'),
(11605469, 'Fadilla Azzahra', 'P', 'Cis 3', 'TKJ XI-2'),
(11605470, 'Fadlan Naufal', 'L', 'Cib 3', 'RPL XI-3'),
(11605471, 'Fadli Abdan Syakur', 'L', 'Wik 4', 'RPL XI-1'),
(11605472, 'Fadliansyah Rusly', 'L', 'Cic 1', 'RPL XI-2'),
(11605473, 'Fadly Laudza Anggadipraja', 'L', 'Cia 4', 'MMD XI-2'),
(11605474, 'Fajar Subeki', 'L', 'Cis 5', 'RPL XI-3'),
(11605475, 'Fakih Septiana Nasrulloh', 'L', 'Cis 1', 'APK XI-3'),
(11605476, 'Faradila Intan Osykawati', 'P', 'Cic 1', 'RPL XI-4'),
(11605477, 'Farhan Banyu Febryan', 'L', 'Cis 2', 'RPL XI-1'),
(11605478, 'Farhan Muhammad', 'L', 'Cic 1', 'RPL XI-4'),
(11605479, 'Farika Amanda Setiawan', 'P', 'Cis 2', 'RPL XI-4'),
(11605480, 'Farrel Arviana Saulani', 'L', 'Suk 1', 'TKJ XI-2'),
(11605481, 'Fatma Agustina', 'P', 'Cic 1', 'APK XI-1'),
(11605482, 'Fauzi Fadillah', 'L', 'Wik 1', 'RPL XI-3'),
(11605483, 'Fauziah Fazriani', 'P', 'Cib 1', 'APK XI-2'),
(11605484, 'Fauzie Hasbi Assidiqi', 'L', 'Taj 3', 'TKJ XI-1'),
(11605485, 'Febriani Putri Afgani', 'P', 'Cic 4', 'APK XI-3'),
(11605487, 'Ferdilliano Wazis', 'L', 'Cis 6', 'PMN XI-1'),
(11605488, 'Ferdiyan Syaputra', 'L', 'Cic 7', 'RPL XI-2'),
(11605489, 'Fetty Fatimah', 'P', 'Cib 3', 'APK XI-1'),
(11605490, 'Fiky Taufik', 'L', 'Cia 4', 'RPL XI-3'),
(11605491, 'Firda Nurhidayanti', 'P', 'Taj 4', 'APK XI-1'),
(11605492, 'Fitri Aldeniya', 'P', 'Suk 1', 'MMD XI-2'),
(11605493, 'Fitri Handayani', 'P', 'Cis 3', 'APK XI-4'),
(11605494, 'Friska Meyliana', 'P', 'Taj 3', 'APK XI-3'),
(11605495, 'Frista Maulia Putri', 'P', 'Suk 1', 'APK XI-2'),
(11605496, 'Futri Aliepiah Yulianti', 'P', 'Wik 4', 'APK XI-2'),
(11605497, 'Galih Rakasiwi', 'L', 'Cis 2', 'RPL XI-4'),
(11605499, 'GENA NOVIA PRILALITA', 'P', 'Cic 6', 'MMD XI-3'),
(11605500, 'Ginanjar Hadie Permana', 'L', 'Cia 5', 'MMD XI-2'),
(11605501, 'Gunadi Yudawiria', 'L', 'Wik 4', 'MMD XI-2'),
(11605502, 'Hafizdul Insan', 'L', 'Taj 4', 'RPL XI-4'),
(11605503, 'Haikal Fikri Luzain', 'L', 'Wik 4', 'RPL XI-3'),
(11605504, 'Hanida Khairunnisa', 'P', 'Cib 2', 'MMD XI-2'),
(11605505, 'Hari Herdiawan', 'L', 'Cia 4', 'RPL XI-2'),
(11605506, 'Haris Yowangga', 'L', 'Taj 5', 'TKJ XI-2'),
(11605507, 'Haryati', 'P', 'Cib 1', 'APK XI-4'),
(11605508, 'Hashfi Ihkamuddin', 'L', 'Suk 1', 'RPL XI-2'),
(11605509, 'Herdi Rismansyah', 'L', 'Cia 3', 'TKJ XI-1'),
(11605510, 'Hira Maulana', 'L', 'Suk 2', 'RPL XI-1'),
(11605511, 'Husein Putra Widya Pratama', 'L', 'Cis 4', 'RPL XI-2'),
(11605512, 'Ia Siti Robiah', 'P', 'Cis 4', 'PMN XI-2'),
(11605513, 'Igo Ferdiawan Syahputra', 'L', 'Wik 4', 'RPL XI-4'),
(11605515, 'Ilka Tishia Dalilah', 'P', 'Wik 4', 'MMD XI-3'),
(11605516, 'Imam Bahy Putra Susetyo', 'L', 'Wik 4', 'RPL XI-4'),
(11605517, 'Imanuel Crucifixio Denta Wirabuana', 'L', 'Cic 4', 'RPL XI-3'),
(11605518, 'Indri Meidiani', 'P', 'Cis 5', 'APK XI-2'),
(11605519, 'Indrianingsih', 'P', 'Taj 5', 'APK XI-3'),
(11605520, 'Indriyanti', 'P', 'Cib 1', 'APK XI-1'),
(11605521, 'Inggih Surya Ningsih', 'P', 'Cia 5', 'APK XI-2'),
(11605522, 'Injanurelia Hayat', 'P', 'Cis 2', 'APK XI-1'),
(11605523, 'Intan Gita Pradini', 'P', 'Cic 6', 'MMD XI-1'),
(11605524, 'Iputu Aldy Cahya Kusuma', 'L', 'Cic 6', 'RPL XI-3'),
(11605525, 'Ires Herlinawati Gunawan', 'P', 'Cib 1', 'PMN XI-1'),
(11605526, 'Irfan Priyadi Nurfauzi', 'L', 'Taj 4', 'RPL XI-1'),
(11605527, 'Irva Nur Fitriyani', 'P', 'Cis 4', 'APK XI-4'),
(11605528, 'Isra Abdillah Maulana', 'L', 'Cic 6', 'RPL XI-4'),
(11605529, 'Janwar Adi Jatmiko', 'L', 'Cic 7', 'MMD XI-1'),
(11605530, 'Jessa Ardithya Chriswantoro', 'L', 'Cic 4', 'RPL XI-1'),
(11605531, 'Jidan Jaelani', 'L', 'Cis 2', 'RPL XI-4'),
(11605532, 'Jihan Miranti', 'P', 'Cic 6', 'RPL XI-1'),
(11605533, 'Jonatan Sianipar', 'L', 'Cic 7', 'PMN XI-2'),
(11605534, 'Josephine Aprilia Sugianto', 'P', 'Cis 4', 'PMN XI-1'),
(11605535, 'Joya Almira Balqist Abigail', 'P', 'Cia 4', 'MMD XI-2'),
(11605536, 'Juan Karel Moenty', 'L', 'Taj 2', 'MMD XI-2'),
(11605537, 'Karina Nurul Fadilah', 'P', 'Cic 3', 'APK XI-2'),
(11605538, 'Kautsar Albana', 'L', 'Taj 3', 'RPL XI-4'),
(11605539, 'Kelvin Dwi Nugraha', 'L', 'Suk 1', 'MMD XI-3'),
(11605540, 'Kevin AXL Yohanes Wagey', 'L', 'Cia 4', 'MMD XI-2'),
(11605541, 'Khansa Tsabitah Ariyani', 'P', 'Wik 4', 'MMD XI-1'),
(11605542, 'Khonsa Khoulah', 'P', 'Cic 6', 'MMD XI-2'),
(11605543, 'Laila Holidah Fatmawati', 'P', 'Cic 3', 'APK XI-3'),
(11605544, 'Laili Nurdina', 'P', 'Cis 2', 'APK XI-3'),
(11605545, 'Lalita Darin Kalya', 'P', 'Wik 2', 'MMD XI-3'),
(11605546, 'Lia Aditia Putri', 'P', 'Cic 1', 'APK XI-4'),
(11605547, 'Liana Nur Rizqi', 'P', 'Suk 2', 'APK XI-1'),
(11605548, 'Lidia Puspitasari', 'P', 'Suk 1', 'APK XI-4'),
(11605549, 'Lintang Oktavia', 'P', 'Cia 5', 'APK XI-3'),
(11605550, 'Lio Lukman', 'L', 'Cic 7', 'PMN XI-2'),
(11605551, 'Lisma Retnawati', 'P', 'Cic 4', 'APK XI-1'),
(11605552, 'Listia Wati', 'P', 'Cia 4', 'APK XI-1'),
(11605553, 'Listiana Putri Utami', 'P', 'Taj 3', 'APK XI-4'),
(11605554, 'Lurin Andriani', 'P', 'Cis 3', 'RPL XI-1'),
(11605555, 'Luthfie Zikri Ramdhani', 'L', 'Cic 6', 'RPL XI-4'),
(11605556, 'Muhammad Adib Syarif', 'L', 'Wik 4', 'RPL XI-2'),
(11605557, 'Muhammad Arif Rahmatullah', 'L', 'Cic 1', 'RPL XI-3'),
(11605558, 'M. Baithul Athiq', 'L', 'Wik 4', 'RPL XI-4'),
(11605559, 'M. Chairul Anwar', 'L', 'Cis 6', 'RPL XI-4'),
(11605560, 'M. Daffa Van Raalten', 'L', 'Cis 4', 'MMD XI-1'),
(11605561, 'M. Fajar Putra Sopian', 'L', 'Cis 2', 'RPL XI-1'),
(11605562, 'M. Figo Haffidz Akbar', 'L', 'Cis 2', 'RPL XI-1'),
(11605563, 'Muhamad Fiqri Rizki Alamsyah', 'L', 'Cis 3', 'PMN XI-2'),
(11605564, 'M. Ghifari Fadhlurrahman', 'L', 'Cic 3', 'TKJ XI-2'),
(11605565, 'M. Rifky Setiadji', 'L', 'Cib 3', 'RPL XI-4'),
(11605566, 'M. Rival Rizmawan', 'L', 'Cic 7', 'TKJ XI-1'),
(11605567, 'M. Rully Fathurahman', 'L', 'Taj 3', 'MMD XI-2'),
(11605568, 'Maedina Nur Hikmah', 'P', 'Cis 2', 'TKJ XI-2'),
(11605569, 'Malwa Saharani', 'P', 'Cis 3', 'MMD XI-1'),
(11605570, 'Marwah Oktaviani', 'P', 'Wik 2', 'APK XI-2'),
(11605571, 'Maulana Amsori', 'L', 'Cic 7', 'MMD XI-1'),
(11605572, 'Maulana Ramadhan', 'L', 'Taj 4', 'TKJ XI-2'),
(11605573, 'Mega Lestari', 'P', 'Cia 4', 'APK XI-2'),
(11605575, 'Mega Sulistiawati', 'P', 'Cia 3', 'MMD XI-3'),
(11605577, 'Mentari Adelia', 'P', 'Taj 4', 'MMD XI-3'),
(11605578, 'Metyo Angga Putra', 'L', 'Cic 7', 'RPL XI-2'),
(11605579, 'Mikhail Raihan Ar-rayyan', 'L', 'Cic 1', 'MMD XI-1'),
(11605580, 'Mila Rosa', 'P', 'Cic 4', 'RPL XI-2'),
(11605581, 'Mila Safitri', 'P', 'Cic 1', 'RPL XI-4'),
(11605582, 'Mira Amelia', 'P', 'Cib 2', 'APK XI-4'),
(11605583, 'Moch Fa`ad Fadilah Syarif', 'L', 'Wik 4', 'RPL XI-4'),
(11605584, 'Moch. Ilham Alhadi', 'L', 'Cic 3', 'RPL XI-1'),
(11605585, 'Moch. Rian Suhada', 'L', 'Cis 4', 'RPL XI-1'),
(11605586, 'Mochamad Agil Setiawan', 'L', 'Cia 5', 'MMD XI-2'),
(11605587, 'Mochamad Marcel', 'L', 'Taj 4', 'RPL XI-1'),
(11605588, 'Mochamad Rifki Ramadhan', 'L', 'Cib 1', 'RPL XI-1'),
(11605589, 'Mochamad Syahrul Aripin', 'L', 'Cic 5', 'MMD XI-3'),
(11605590, 'Mochammad Ravi Suhendra', 'L', 'Cis 6', 'RPL XI-1'),
(11605591, 'Mohamad Dicky Andrian', 'L', 'Taj 4', 'MMD XI-1'),
(11605593, 'Mohamad Robby Herlambang', 'L', 'Cic 7', 'TKJ XI-1'),
(11605594, 'Mohammad Arshy Ramdhani', 'L', 'Cic 5', 'MMD XI-1'),
(11605595, 'Muftagi Arman Maulana', 'L', 'Cis 4', 'MMD XI-2'),
(11605596, 'Muhamad Adam Zildan', 'L', 'Cis 3', 'PMN XI-1'),
(11605597, 'Muhamad Aditya Widicaksono', 'L', 'Taj 2', 'MMD XI-1'),
(11605598, 'Muhamad Agus Fikri', 'L', 'Cib 2', 'MMD XI-2'),
(11605599, 'Muhamad Ahrul Syamil Ulum', 'L', 'Cis 5', 'RPL XI-3'),
(11605600, 'Muhamad Ajwanudin', 'L', 'Cib 3', 'RPL XI-1'),
(11605601, 'Muhamad Aldifa Maulana', 'L', 'Cia 5', 'APK XI-4'),
(11605602, 'Muhamad Alfi Ardiansyah', 'L', 'Cis 3', 'TKJ XI-1'),
(11605603, 'Muhamad Alfin', 'L', 'Cib 2', 'RPL XI-1'),
(11605604, 'Muhamad Alif Viandi Zulfikor', 'L', 'Cia 3', 'TKJ XI-2'),
(11605605, 'Muhamad Aqil Atthoriq', 'L', 'Wik 4', 'PMN XI-1'),
(11605606, 'Muhamad Awaludin Nugraha', 'L', 'Cia 4', 'MMD XI-3'),
(11605607, 'Muhamad Azril', 'L', 'Taj 4', 'MMD XI-1'),
(11605608, 'Muhamad Didi Wahyudi', 'L', 'Cis 4', 'RPL XI-1'),
(11605609, 'Muhamad Fikri Haikal', 'L', 'Taj 5', 'PMN XI-2'),
(11605610, 'Muhamad Habil Fathurahman', 'L', 'Cia 1', 'MMD XI-2'),
(11605611, 'Muhamad Ikhsan Maulana', 'L', 'Cis 5', 'RPL XI-2'),
(11605612, 'Muhamad Ilham', 'L', 'Cia 2', 'RPL XI-4'),
(11605613, 'Muhamad Ilham Ramadhan', 'L', 'Cis 1', 'MMD XI-2'),
(11605614, 'Muhamad Ilham Sihabudin', 'L', 'Wik 1', 'RPL XI-2'),
(11605615, 'Muhamad Iqbal Faturrahman', 'L', 'Suk 2', 'RPL XI-2'),
(11605616, 'Muhamad Iqbal Nurhadi', 'L', 'Wik 3', 'PMN XI-2'),
(11605617, 'Muhamad Jalaludin', 'L', 'Wik 1', 'RPL XI-4'),
(11605618, 'Muhamad Meidy Mahardika', 'L', 'Cis 4', 'RPL XI-2'),
(11605619, 'Muhamad Miftah', 'L', 'Cib 3', 'RPL XI-3'),
(11605620, 'Muhamad Naufal Azmi', 'L', 'Cis 5', 'RPL XI-1'),
(11605621, 'Muhamad Naufal Meidiyawan', 'L', 'Cia 1', 'PMN XI-1'),
(11605623, 'Muhamad Rafli Irfansyah', 'L', 'Cis 5', 'RPL XI-2'),
(11605624, 'Muhammad Raudhon Maulana', 'L', 'Cic 5', 'TKJ XI-2'),
(11605625, 'Muhamad Rehan', 'L', 'Cis 5', 'TKJ XI-1'),
(11605626, 'Muhamad Rian Maulana', 'L', 'Suk 2', 'RPL XI-4'),
(11605627, 'Muhamad Rifa`i', 'L', 'Cic 4', 'TKJ XI-2'),
(11605628, 'Muhamad Risky Figo', 'L', 'Cic 7', 'MMD XI-3'),
(11605629, 'Muhamad Rivaldi', 'L', 'Cib 3', 'RPL XI-3'),
(11605630, 'Muhamad Rizal Erwiansyah', 'L', 'Cib 3', 'RPL XI-4'),
(11605631, 'Muhamad Rizki', 'L', 'Taj 5', 'RPL XI-1'),
(11605632, 'Muhamad Rizki Maulana', 'L', 'Cis 4', 'TKJ XI-1'),
(11605633, 'Muhamad Rizky Novriadi', 'L', 'Cia 2', 'MMD XI-1'),
(11605634, 'Muhamad Rizqi Permadi', 'L', 'Taj 5', 'MMD XI-3'),
(11605635, 'Muhamad Sadam Husen', 'L', 'Cib 3', 'APK XI-2'),
(11605636, 'Muhamad Saprudin', 'L', 'Cib 2', 'PMN XI-2'),
(11605637, 'Muhamad Sechan Syadat', 'L', 'Cia 5', 'RPL XI-2'),
(11605638, 'Muhamad Sofian Hidayat', 'L', 'Cic 5', 'PMN XI-1'),
(11605639, 'Muhamad Sopian Sauri', 'L', 'Cis 3', 'MMD XI-1'),
(11605640, 'Muhamad Tubagus Rangga', 'L', 'Cic 3', 'RPL XI-2'),
(11605641, 'Muhamad Wildan', 'L', 'Cis 6', 'RPL XI-2'),
(11605642, 'Muhamad Yerdilah Riziq', 'L', 'Cic 5', 'TKJ XI-1'),
(11605643, 'Muhamad Yusdi Fajri', 'L', 'Cis 2', 'TKJ XI-1'),
(11605645, 'Muhammad Adilla', 'L', 'Taj 4', 'APK XI-4'),
(11605646, 'Muhammad Akbar Maureksa', 'L', 'Wik 4', 'RPL XI-2'),
(11605647, 'Muhammad Anjas Ambia', 'L', 'Cic 3', 'TKJ XI-2'),
(11605648, 'Muhammad Arda Bily', 'L', 'Cia 1', 'MMD XI-1'),
(11605649, 'Muhammad Ardiansyah', 'L', 'Cic 4', 'TKJ XI-2'),
(11605650, 'Muhammad Arif Syauqi Beik', 'L', 'Taj 3', 'MMD XI-1'),
(11605651, 'Muhammad Ashadi', 'L', 'Cic 1', 'PMN XI-1'),
(11605652, 'Muhammad Azril Akbar', 'L', 'Cic 4', 'RPL XI-3'),
(11605653, 'Muhammad Basman Jamal', 'L', 'Suk 2', 'PMN XI-1'),
(11605654, 'Muhammad Daud Satibi', 'L', 'Suk 2', 'APK XI-2'),
(11605655, 'Muhammad Dervan Armanda', 'L', 'Cia 1', 'MMD XI-2'),
(11605656, 'Muhammad Eggy Abdal Saputra', 'L', 'Cis 3', 'RPL XI-4'),
(11605657, 'Muhammad Fahran Januar', 'L', 'Cia 2', 'PMN XI-1'),
(11605658, 'Muhammad Fajar Darmawan', 'L', 'Cia 3', 'RPL XI-4'),
(11605660, 'Muhammad Farhan Fahrurrozi', 'L', 'Cic 5', 'TKJ XI-1'),
(11605662, 'Muhammad Febriansyah', 'L', 'Taj 4', 'TKJ XI-2'),
(11605663, 'Muhammad Fikri Bima Nugraha', 'L', 'Wik 1', 'RPL XI-3'),
(11605664, 'Muhammad Fikri Sanjaya', 'L', 'Cic 3', 'MMD XI-1'),
(11605665, 'Muhammad Firman Prayoga', 'L', 'Cia 5', 'RPL XI-4'),
(11605666, 'Muhammad Hamidi', 'L', 'Cic 3', 'MMD XI-1'),
(11605667, 'Muhammad Ikbal Suhada', 'L', 'Cic 3', 'TKJ XI-1'),
(11605668, 'Muhammad Ilyas', 'L', 'Cis 5', 'RPL XI-1'),
(11605669, 'Muhammad Iqbal Febrian', 'L', 'Cia 2', 'MMD XI-1'),
(11605670, 'Muhammad Irsan Aditia', 'L', 'Cia 2', 'TKJ XI-2'),
(11605671, 'Muhammad Lukmanulhakim', 'L', 'Cis 4', 'RPL XI-2'),
(11605672, 'Muhammad Lutfi', 'L', 'Cia 5', 'TKJ XI-1'),
(11605673, 'Muhammad Najib Firdaus', 'L', 'Cis 5', 'RPL XI-4'),
(11605674, 'Muhammad Naufal Shabir', 'L', 'Suk 1', 'RPL XI-1'),
(11605675, 'Muhammad Nazif', 'L', 'Wik 4', 'TKJ XI-1'),
(11605678, 'Muhammad Rafizki', 'L', 'Cis 4', 'TKJ XI-1'),
(11605679, 'Muhammad Ramadhani', 'L', 'Cib 3', 'RPL XI-2'),
(11605680, 'Muhammad Ramdhan', 'L', 'Cic 5', 'TKJ XI-2'),
(11605681, 'Muhammad Randy Maulana', 'L', 'Cia 3', 'MMD XI-3'),
(11605683, 'Muhammad Reza Fahlevi Hamzah', 'L', 'Cis 3', 'TKJ XI-2'),
(11605684, 'Muhammad Rivan Khatami', 'L', 'Suk 1', 'MMD XI-1'),
(11605685, 'Muhammad Saepu Baldan', 'L', 'Cic 1', 'PMN XI-1'),
(11605686, 'Muhammad Salman Riski Saputra', 'L', 'Cib 3', 'RPL XI-1'),
(11605687, 'Muhammad Sopian', 'L', 'Cib 3', 'RPL XI-1'),
(11605688, 'Muhammad Suwardi Firdaus', 'L', 'Taj 3', 'TKJ XI-1'),
(11605689, 'Muhammad Wildan Fauzi', 'L', 'Cib 2', 'TKJ XI-2'),
(11605690, 'Mukti Prasatya Rahardja', 'L', 'Taj 5', 'MMD XI-2'),
(11605691, 'Mupida Safitri', 'P', 'Taj 4', 'APK XI-2'),
(11605692, 'Murni Zulia Hadstuti', 'P', 'Cib 1', 'APK XI-3'),
(11605693, 'Mutiara Rizkyna Arlinda', 'P', 'Cis 4', 'RPL XI-1'),
(11605694, 'Mutiara Widianti Sukma', 'P', 'Wik 3', 'RPL XI-1'),
(11605695, 'Nabila Fitriani', 'P', 'Cis 2', 'MMD XI-2'),
(11605696, 'Nabila Hermawati', 'P', 'Cic 7', 'RPL XI-2'),
(11605697, 'Nadia Septiani', 'P', 'Cib 1', 'APK XI-3'),
(11605698, 'Nana Rudiana', 'L', 'Cib 1', 'PMN XI-1'),
(11605699, 'Nasir Ahmad', 'L', 'Taj 5', 'PMN XI-2'),
(11605700, 'Natasha', 'P', 'Suk 2', 'RPL XI-3'),
(11605701, 'Naufal Tiftazani', 'L', 'Cib 1', 'PMN XI-2'),
(11605702, 'Naufal Widad Irawan', 'L', 'Cia 1', 'PMN XI-2'),
(11605703, 'Navy Putri Marini', 'P', 'Wik 1', 'APK XI-1'),
(11605704, 'Nia Indriani', 'P', 'Cic 3', 'APK XI-4'),
(11605705, 'Niken Rahmadani', 'P', 'Cib 3', 'MMD XI-2'),
(11605706, 'Nina Rahma Aulia', 'P', 'Cic 1', 'APK XI-4'),
(11605707, 'Nina Rosdiana', 'P', 'Taj 4', 'MMD XI-3'),
(11605708, 'Nisa Maulida', 'P', 'Cib 2', 'APK XI-2'),
(11605709, 'Nita Anggraeni', 'P', 'Taj 4', 'RPL XI-2'),
(11605710, 'Nita Elinda', 'P', 'Wik 2', 'TKJ XI-1'),
(11605711, 'Noer Muhamad Reksy Agus Saputra', 'L', 'Wik 3', 'PMN XI-1'),
(11605712, 'Noer Samantha Chaerunnisa', 'P', 'Taj 2', 'APK XI-2'),
(11605713, 'Noor Aghni Aulia Pratiwi', 'P', 'Suk 2', 'MMD XI-2'),
(11605714, 'Noviana Eni Marlufi', 'P', 'Cic 1', 'APK XI-3'),
(11605715, 'Noviansyah Caturnanda Saputra', 'L', 'Cis 3', 'TKJ XI-2'),
(11605716, 'Novica Ardina', 'P', 'Cic 7', 'RPL XI-1'),
(11605717, 'Nugi Nugroho', 'L', 'Cic 4', 'TKJ XI-1'),
(11605718, 'Nur Aini Lubis', 'P', 'Taj 3', 'APK XI-4'),
(11605719, 'Nur Arini Erdiani Soleha', 'P', 'Cic 7', 'APK XI-3'),
(11605720, 'Nur Fitri Apriani Harahap', 'P', 'Cic 3', 'APK XI-1'),
(11605721, 'Nur Khopipah', 'P', 'Taj 4', 'RPL XI-2'),
(11605722, 'Nur Muhammad Muddatsir', 'L', 'Cic 6', 'MMD XI-3'),
(11605723, 'Nurdian Fitri Ningsih', 'P', 'Wik 2', 'APK XI-1'),
(11605724, 'Nurhadi Yusup', 'L', 'Suk 1', 'TKJ XI-2'),
(11605725, 'Nurrizki Pratama', 'L', 'Suk 1', 'APK XI-3'),
(11605726, 'Nurul Awaliyaturohmah', 'P', 'Cic 1', 'MMD XI-1'),
(11605727, 'Nurul Fauziah', 'P', 'Cic 7', 'APK XI-1'),
(11605728, 'Nurul Qurrotu Aeni', 'P', 'Cia 3', 'MMD XI-2'),
(11605729, 'Nurul Salma Musafa', 'P', 'Cic 5', 'APK XI-4'),
(11605730, 'Nyai Misih', 'P', 'Taj 5', 'MMD XI-3'),
(11605731, 'Osi Rias Wasubhi', 'L', 'Taj 5', 'TKJ XI-1'),
(11605732, 'Pipit Nur Apipah', 'P', 'Cic 3', 'APK XI-4'),
(11605733, 'Prama Prakasa', 'L', 'Taj 3', 'RPL XI-4'),
(11605734, 'Pramudya Saputra', 'L', 'Cic 4', 'RPL XI-3'),
(11605735, 'Pranajaya Sulaiman Basyir', 'L', 'Cib 2', 'RPL XI-1'),
(11605736, 'Pratama Miswa Nugraha', 'L', 'Cis 4', 'MMD XI-3'),
(11605737, 'Putra Alief Hermawan', 'L', 'Cib 2', 'MMD XI-3'),
(11605738, 'Putra Haekal Ghifari', 'L', 'Cib 3', 'TKJ XI-2'),
(11605739, 'Putri Apryanti', 'P', 'Cib 1', 'APK XI-1'),
(11605740, 'Putri Fadella Ari Aluna', 'P', 'Cic 1', 'APK XI-2'),
(11605741, 'Putri Pratiwi', 'P', 'Cis 3', 'APK XI-2'),
(11605742, 'Putri Salma Wulandari', 'P', 'Cic 3', 'RPL XI-2'),
(11605743, 'Putri Siti Nurulita Idris', 'P', 'Cis 6', 'MMD XI-3'),
(11605744, 'Putri Yasinta', 'P', 'Taj 3', 'APK XI-2'),
(11605745, 'Putriana Rizka Pamungkas', 'P', 'Cis 2', 'MMD XI-1'),
(11605746, 'Putriyani', 'P', 'Cia 3', 'APK XI-3'),
(11605747, 'Qonitat Sholihah', 'P', 'Cis 5', 'APK XI-1'),
(11605748, 'R. Siti Hanipah', 'P', 'Cis 2', 'APK XI-2'),
(11605749, 'Raafi Husain Kamil', 'L', 'Taj 1', 'TKJ XI-2'),
(11605750, 'Rachel Nanulaitta', 'P', 'Cis 1', 'MMD XI-2'),
(11605752, 'Raden Desti Safitri', 'P', 'Cis 4', 'APK XI-1'),
(11605754, 'Raditka Adha', 'L', 'Suk 2', 'RPL XI-4'),
(11605755, 'Radja Raiyan Trixy Salafy', 'L', 'Cis 3', 'MMD XI-3'),
(11605756, 'Rafa Nur Adilah', 'P', 'Cic 5', 'RPL XI-3'),
(11605757, 'Rafi Pratama Merta', 'L', 'Cib 2', 'RPL XI-3'),
(11605758, 'Rafli Maulana Rizki', 'L', 'Cia 1', 'RPL XI-3'),
(11605759, 'Ragis Nuriansyah Putra', 'L', 'Cis 5', 'PMN XI-2'),
(11605760, 'Raihan Fajari', 'L', 'Wik 4', 'RPL XI-3'),
(11605763, 'Raka Agus Chandra', 'L', 'Cis 2', 'RPL XI-2'),
(11605764, 'Rama Yudha Agustira', 'L', 'Cic 3', 'MMD XI-2'),
(11605766, 'Rangga Mahendra Yusup', 'L', 'Taj 3', 'RPL XI-1'),
(11605767, 'Rayna Russena', 'P', 'Suk 2', 'MMD XI-1'),
(11605768, 'Raysa Afni', 'P', 'Wik 2', 'APK XI-3'),
(11605769, 'Razi Mawlana Yusuf', 'L', 'Wik 4', 'TKJ XI-1'),
(11605770, 'Refasya Ika Pramesti', 'P', 'Cib 2', 'APK XI-3'),
(11605771, 'Reinandy Fediyanto', 'L', 'Cic 4', 'RPL XI-1'),
(11605772, 'Rena Wahyuni', 'P', 'Cia 5', 'APK XI-1'),
(11605773, 'Renata Indah Ningrum Siahaan', 'P', 'Cib 2', 'MMD XI-1'),
(11605774, 'Rendy Saputra Jamin', 'L', 'Cia 3', 'MMD XI-2'),
(11605775, 'Renisa Qori Adinda', 'P', 'Cib 2', 'APK XI-2'),
(11605776, 'Resya Putri Kemala', 'P', 'Cis 1', 'MMD XI-3'),
(11605777, 'Reva Putri Amalia', 'P', 'Taj 5', 'MMD XI-3'),
(11605778, 'Revanza Wicak Pangestu', 'L', 'Cic 4', 'PMN XI-2'),
(11605779, 'Reynaldi Saputra', 'L', 'Cic 6', 'PMN XI-2'),
(11605780, 'Reza Fitria Tarwiyah', 'P', 'Cic 3', 'APK XI-4'),
(11605781, 'Reza Kharisma Muhammad', 'L', 'Cic 6', 'TKJ XI-2'),
(11605782, 'Rhavy Julian Pradana', 'L', 'Cib 1', 'PMN XI-2'),
(11605783, 'Rian Subagya', 'L', 'Taj 3', 'TKJ XI-2'),
(11605784, 'Ricken Fillany', 'P', 'Cic 7', 'APK XI-4'),
(11605785, 'Rifki Ananda', 'L', 'Cia 3', 'APK XI-1'),
(11605786, 'Rifki Rustandi', 'L', 'Cia 4', 'RPL XI-2'),
(11605788, 'Rifqi Faadillah Azhar', 'L', 'Cia 3', 'PMN XI-1'),
(11605789, 'Rihan Alrieva Prihadi', 'L', 'Cis 5', 'MMD XI-3'),
(11605790, 'Rika Rahmawati', 'P', 'Cia 2', 'APK XI-3'),
(11605791, 'Riky Wijaya', 'L', 'Cis 3', 'RPL XI-1'),
(11605792, 'Rima Regiani', 'P', 'Cib 1', 'RPL XI-2'),
(11605793, 'Rina Alawiyah', 'P', 'Cic 4', 'APK XI-4'),
(11605794, 'Rini Indriyani', 'P', 'Cia 3', 'APK XI-1'),
(11605795, 'Rio Maulana', 'L', 'Taj 4', 'PMN XI-2'),
(11605796, 'Riri Nurma Herwini', 'P', 'Cis 6', 'APK XI-2'),
(11605797, 'Riska Ekayana Putri', 'P', 'Cic 3', 'APK XI-4'),
(11605798, 'Riska Sulistiawati', 'P', 'Wik 3', 'MMD XI-3'),
(11605799, 'Risma Yunianti', 'P', 'Cis 3', 'APK XI-1'),
(11605800, 'Riyan Maulana Putra', 'L', 'Taj 3', 'RPL XI-2'),
(11605801, 'Rizal Bimantoro', 'L', 'Cic 1', 'MMD XI-3'),
(11605802, 'Rizal Ikhsan Pratama', 'L', 'Taj 1', 'MMD XI-1'),
(11605803, 'Rizki Indra Bayu', 'L', 'Cib 1', 'TKJ XI-2'),
(11605804, 'Rizky Nasrullah', 'L', 'Cia 1', 'MMD XI-1'),
(11605805, 'Rizky Widiyanto', 'L', 'Suk 2', 'RPL XI-3'),
(11605806, 'Robbi Hably Minassholihyn', 'L', 'Taj 4', 'TKJ XI-1'),
(11605807, 'Runi Khaerunisa', 'P', 'Cis 6', 'APK XI-2'),
(11605808, 'Ruslan Fadilah', 'L', 'Cis 4', 'MMD XI-2'),
(11605809, 'Ryan Prasastian', 'L', 'Cis 2', 'PMN XI-2'),
(11605811, 'Saeful Reiza Nourmansah', 'L', 'Cic 5', 'TKJ XI-1'),
(11605812, 'Saefullah Wafa', 'L', 'Cic 7', 'TKJ XI-1'),
(11605813, 'Safinah Apriliyani', 'P', 'Cic 3', 'APK XI-2'),
(11605814, 'Safitri Suci Rahayu', 'P', 'Cic 3', 'MMD XI-3'),
(11605815, 'Saiful Maulana', 'L', 'Taj 4', 'PMN XI-2'),
(11605816, 'Salma Nazhifah', 'P', 'Cib 2', 'MMD XI-3'),
(11605817, 'Salman Hardi Priatna', 'L', 'Cic 7', 'PMN XI-1'),
(11605818, 'Salsa Aulia Anjari', 'P', 'Cic 7', 'MMD XI-1'),
(11605819, 'Salsabila Qurotuain', 'P', 'Cic 6', 'RPL XI-1'),
(11605820, 'Salsadilah', 'P', 'Cib 1', 'MMD XI-2'),
(11605821, 'Salsha Desviani', 'P', 'Cia 3', 'APK XI-2'),
(11605822, 'Salwa Rizky Aulia', 'P', 'Cic 5', 'APK XI-1'),
(11605823, 'Salzhadina Anggita', 'P', 'Taj 4', 'MMD XI-2'),
(11605824, 'Sandhika Ferly Sidiq', 'L', 'Cic 5', 'PMN XI-2'),
(11605826, 'Sandra Zettira', 'P', 'Cic 1', 'APK XI-3'),
(11605827, 'Saprila Wijaya', 'P', 'Cia 5', 'TKJ XI-2'),
(11605828, 'Sari Nurfika', 'P', 'Cia 5', 'APK XI-4'),
(11605829, 'Saripah Nabila', 'P', 'Taj 3', 'RPL XI-2'),
(11605830, 'Saskia Intan Ramadhanti', 'P', 'Cib 1', 'APK XI-3'),
(11605831, 'Satrio Nuur Adi Prawiro', 'L', 'Cic 4', 'RPL XI-2'),
(11605833, 'Sehira Agya Salsabillah', 'P', 'Cib 3', 'APK XI-4'),
(11605834, 'Selvi Noviliana', 'P', 'Cic 5', 'APK XI-1'),
(11605835, 'Sendy Hartanto', 'L', 'Taj 5', 'RPL XI-2'),
(11605836, 'Sephia Tri Handayani', 'P', 'Wik 4', 'PMN XI-2'),
(11605837, 'Septi Hatami Selvia Muntila', 'P', 'Cic 1', 'PMN XI-2'),
(11605838, 'Septia Arieska', 'P', 'Cis 3', 'MMD XI-1'),
(11605839, 'Septiani Zulkarnain', 'P', 'Taj 5', 'APK XI-2'),
(11605840, 'Septio Surya Mustaqim', 'L', 'Wik 2', 'TKJ XI-1'),
(11605841, 'Shantika Dwi', 'P', 'Wik 3', 'MMD XI-2'),
(11605842, 'Shevtya Rahmawaty', 'P', 'Wik 1', 'PMN XI-1'),
(11605843, 'Shofi Luthfiah', 'P', 'Taj 4', 'PMN XI-2'),
(11605844, 'Silvi Anggiastuti', 'P', 'Cis 6', 'APK XI-3'),
(11605845, 'Silvi Nurfadhilah', 'P', 'Cia 1', 'APK XI-2'),
(11605846, 'Silvia Anggraeni', 'P', 'Cia 5', 'APK XI-4'),
(11605847, 'Silvia Irma Wahyudi', 'P', 'Taj 5', 'MMD XI-2'),
(11605848, 'Sindi Iklimah Nurul Apriani', 'P', 'Cia 4', 'APK XI-1'),
(11605849, 'Siti Alfi Wahidah', 'P', 'Cis 5', 'PMN XI-1'),
(11605850, 'Siti Amalia Ihsan', 'P', 'Cia 5', 'APK XI-1'),
(11605851, 'Siti Assyifah', 'P', 'Cis 4', 'MMD XI-3'),
(11605852, 'Siti Halimah', 'P', 'Wik 1', 'APK XI-3'),
(11605853, 'Siti Inayatul Wahidah', 'P', 'Cic 7', 'APK XI-2'),
(11605854, 'Siti Jahra', 'P', 'Cic 6', 'RPL XI-2'),
(11605855, 'Siti Khodijah', 'P', 'Cis 4', 'APK XI-3'),
(11605856, 'Siti Mariam', 'P', 'Suk 1', 'APK XI-1'),
(11605857, 'Siti Maryamah', 'P', 'Cia 2', 'APK XI-2'),
(11605858, 'Siti Maulidia Sa`adah', 'P', 'Suk 1', 'APK XI-3'),
(11605859, 'Siti Meika Anggita', 'P', 'Cis 5', 'APK XI-4'),
(11605860, 'Siti Meliawati', 'P', 'Cia 4', 'APK XI-3'),
(11605861, 'Siti Nabila Huda', 'P', 'Cib 3', 'RPL XI-3'),
(11605862, 'Siti Nadea', 'P', 'Cic 5', 'APK XI-3'),
(11605863, 'Siti Novi Nurkomala', 'P', 'Cia 2', 'APK XI-2'),
(11605864, 'Siti Nur Aulia', 'P', 'Cic 5', 'APK XI-4'),
(11605865, 'Siti Nur Ubed Ubaedillah', 'P', 'Cis 4', 'RPL XI-4'),
(11605866, 'Siti Nuraeni', 'P', 'Cic 7', 'APK XI-1'),
(11605867, 'Siti Nurheriah', 'P', 'Cia 3', 'APK XI-4'),
(11605868, 'Siti Nurul Fadilah', 'P', 'Cib 3', 'APK XI-1'),
(11605869, 'Siti Robiatul Adawiah', 'P', 'Cis 1', 'APK XI-2'),
(11605870, 'Siti Salbia Sundava', 'P', 'Cis 3', 'APK XI-1'),
(11605871, 'Siti Salwawati', 'P', 'Cia 1', 'PMN XI-1'),
(11605872, 'Siti Sarah', 'P', 'Cia 2', 'MMD XI-3'),
(11605873, 'Siti Silvani Nahrulita', 'P', 'Cis 6', 'APK XI-2'),
(11605874, 'Siti Syahda Rana Areta', 'P', 'Cib 2', 'RPL XI-4'),
(11605875, 'Siti Syarah Namira Nur Azizah', 'P', 'Taj 4', 'APK XI-2'),
(11605876, 'Siti Yulia Nengsih', 'P', 'Cic 4', 'APK XI-3'),
(11605877, 'Siti Yulianti', 'P', 'Cic 7', 'APK XI-3'),
(11605878, 'Sopiatunisa', 'P', 'Taj 2', 'RPL XI-3'),
(11605879, 'Sri Indriyani', 'P', 'Taj 5', 'APK XI-4'),
(11605880, 'Sri Putri Mentari', 'P', 'Cis 5', 'RPL XI-3'),
(11605881, 'Sri Ratih', 'P', 'Cib 2', 'APK XI-3'),
(11605882, 'Sri Siti Wahyuni', 'P', 'Cis 3', 'APK XI-4'),
(11605883, 'Suci Ardila Citra', 'P', 'Cib 2', 'RPL XI-4'),
(11605884, 'Suci Putri Agnesia', 'P', 'Cic 6', 'RPL XI-4'),
(11605885, 'Sulhan Susanto', 'L', 'Taj 3', 'TKJ XI-1'),
(11605886, 'Sultan Putra Ramadan', 'L', 'Cia 3', 'MMD XI-2'),
(11605887, 'Susanto', 'L', 'Cis 5', 'RPL XI-4'),
(11605888, 'Syabrina Salsabilla', 'P', 'Taj 2', 'PMN XI-2'),
(11605889, 'Syahril Sidik', 'L', 'Cib 3', 'TKJ XI-1'),
(11605890, 'Syahrul Kamal', 'L', 'Cis 6', 'TKJ XI-2'),
(11605891, 'Syifa Dwi Anindita Putri', 'P', 'Wik 3', 'MMD XI-3'),
(11605892, 'Syifa Fitriawati', 'P', 'Cia 5', 'APK XI-1'),
(11605893, 'Syifa Gita Meilani', 'P', 'Wik 2', 'PMN XI-2'),
(11605895, 'Syifa Putri Apriliani', 'P', 'Cic 3', 'PMN XI-1'),
(11605896, 'Sylvia Julianti', 'P', 'Cic 3', 'APK XI-1'),
(11605897, 'Tania Pratiwi', 'P', 'Cib 1', 'PMN XI-1'),
(11605898, 'Tarisa Fajarina Satiri', 'P', 'Cia 5', 'APK XI-4'),
(11605899, 'Tasha Andini Afiany', 'P', 'Cib 1', 'APK XI-2'),
(11605900, 'Teddy Haryadi', 'L', 'Cic 6', 'PMN XI-1'),
(11605901, 'Tedi Alamsyah', 'L', 'Cic 4', 'RPL XI-2'),
(11605902, 'Teresa Angelina', 'P', 'Suk 2', 'MMD XI-1'),
(11605903, 'Tesa Nurdiani', 'P', 'Taj 4', 'APK XI-1'),
(11605904, 'Thoriq Abdul Basit', 'L', 'Wik 1', 'MMD XI-1'),
(11605905, 'Tian Ardiansyah Erlangga', 'L', 'Cis 2', 'TKJ XI-2'),
(11605906, 'Tobias Vinsensius Pradana', 'L', 'Wik 1', 'RPL XI-2'),
(11605907, 'Tri Wulan Dari', 'P', 'Cis 4', 'APK XI-2'),
(11605908, 'Tubagus Alif Syahrul Ramdoni', 'L', 'Taj 4', 'RPL XI-3'),
(11605909, 'Vina Nuralviani', 'P', 'Cia 5', 'PMN XI-1'),
(11605910, 'Virna Ameliana Putri', 'P', 'Taj 5', 'MMD XI-1'),
(11605911, 'Virnanda Asmy Luckyta', 'P', 'Cic 5', 'APK XI-3'),
(11605912, 'Wahyudis Hapitaliani', 'P', 'Cia 3', 'APK XI-3'),
(11605913, 'Wahyuni', 'P', 'Taj 5', 'APK XI-4'),
(11605914, 'Wanda Hamidah', 'P', 'Cib 3', 'APK XI-4'),
(11605915, 'Wida Widiyanti Aprilia', 'P', 'Cic 1', 'TKJ XI-1'),
(11605916, 'Willy Halim', 'L', 'Cis 4', 'PMN XI-2'),
(11605917, 'Windi Nuratmalia', 'P', 'Taj 5', 'MMD XI-2'),
(11605918, 'Yovan Arya Nugraha', 'L', 'Taj 3', 'PMN XI-2'),
(11605919, 'Yurisa Iryolusiadivi', 'P', 'Taj 2', 'APK XI-4'),
(11605920, 'Yushi Nur Afifah', 'P', 'Cia 4', 'APK XI-3'),
(11605921, 'Zainal Arifin Famungkas', 'L', 'Wik 1', 'TKJ XI-1'),
(11605922, 'Zeta Caradiva Bulansari', 'P', 'Cis 3', 'APK XI-2'),
(11605923, 'Zhafari Irsyad', 'L', 'Cia 5', 'RPL XI-3'),
(11605924, 'Zhofran Dhiqo Wibisono Wijayanto', 'L', 'Wik 2', 'RPL XI-4'),
(11605926, 'Indra Aulia Gustaldi', 'L', 'Taj 1', 'TKJ XI-1'),
(11605927, 'Shazira Rizky Wahyudi', 'P', 'SUK 1', 'APK XI-3');

-- --------------------------------------------------------

--
-- Table structure for table `tb_skhun`
--

CREATE TABLE `tb_skhun` (
  `nis` int(11) NOT NULL,
  `nisn` int(11) NOT NULL,
  `npun` varchar(25) NOT NULL,
  `sekolah` varchar(225) NOT NULL,
  `npsn` int(11) NOT NULL,
  `no` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_skhun`
--

INSERT INTO `tb_skhun` (`nis`, `nisn`, `npun`, `sekolah`, `npsn`, `no`) VALUES
(11605303, 11605303, '11605303', 'Test', 11605303, 'DN-01 DI/03 6492101'),
(11605304, 11605304, '11605304', 'Test', 11605304, 'DN-01 DI/03 6492102'),
(11605305, 11605305, '11605305', 'Test', 11605305, 'DN-01 DI/03 6492103'),
(11605306, 11605306, '11605306', 'Test', 11605306, 'DN-01 DI/03 6492104'),
(11605307, 11605307, '11605307', 'Test', 11605307, 'DN-01 DI/03 6492105'),
(11605308, 11605308, '11605308', 'Test', 11605308, 'DN-01 DI/03 6492106'),
(11605309, 11605309, '11605309', 'Test', 11605309, 'DN-01 DI/03 6492107'),
(11605310, 11605310, '11605310', 'Test', 11605310, 'DN-01 DI/03 6492108'),
(11605311, 11605311, '11605311', 'Test', 11605311, 'DN-01 DI/03 6492109'),
(11605312, 11605312, '11605312', 'Test', 11605312, 'DN-01 DI/03 6492110'),
(11605511, 11605511, '11605511', 'Test', 11605511, 'DN-01 DI/02 0698223'),
(11605512, 11605512, '11605512', 'Test', 11605512, 'DN-01 DI/03 6492856'),
(11605513, 11605513, '14605513', 'Test', 11605513, '11695513'),
(11605603, 11605603, '11605603', 'Test', 11605603, 'DN-05 F 7682657');

-- --------------------------------------------------------

--
-- Structure for view `qw_ijazah`
--
DROP TABLE IF EXISTS `qw_ijazah`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `qw_ijazah`  AS  select `tb_siswa`.`nis` AS `nis`,`tb_siswa`.`nama_siswa` AS `nama_siswa`,`tb_siswa`.`rayon` AS `rayon`,`tb_ijazah`.`nisn` AS `nisn`,`tb_ijazah`.`npun` AS `npun`,`tb_ijazah`.`no` AS `no` from (`tb_ijazah` join `tb_siswa` on((`tb_ijazah`.`nis` = `tb_siswa`.`nis`))) ;

-- --------------------------------------------------------

--
-- Structure for view `qw_skhun`
--
DROP TABLE IF EXISTS `qw_skhun`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `qw_skhun`  AS  select `tb_siswa`.`nis` AS `nis`,`tb_siswa`.`nama_siswa` AS `nama_siswa`,`tb_siswa`.`rayon` AS `rayon`,`tb_skhun`.`nisn` AS `nisn`,`tb_skhun`.`npun` AS `npun`,`tb_skhun`.`no` AS `no`,`tb_skhun`.`npsn` AS `npsn` from (`tb_skhun` join `tb_siswa` on((`tb_skhun`.`nis` = `tb_siswa`.`nis`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_ijazah`
--
ALTER TABLE `tb_ijazah`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`nis`);

--
-- Indexes for table `tb_skhun`
--
ALTER TABLE `tb_skhun`
  ADD PRIMARY KEY (`nis`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
